import React from 'react'
import Card from './Card'

export default function GridMyCards() {
  return (
    <div className="grid-container">
      {
        /*  myCards.map(card => (
           <Card
             key={card.id}
             card={card}
           />
         )) */
      }
    </div>
  )
}

