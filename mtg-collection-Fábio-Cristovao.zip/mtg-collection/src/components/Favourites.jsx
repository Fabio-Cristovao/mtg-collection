import React from 'react'

export default function Favourites() {
  return (
    <div>
      <h1>Favourites</h1>
    </div>
  )
}

