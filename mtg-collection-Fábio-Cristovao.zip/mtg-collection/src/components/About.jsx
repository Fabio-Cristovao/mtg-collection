import React from 'react'
import Header from './Header'

export default function About() {
  return (
    <div>
      <Header />
    </div>
  )
}
